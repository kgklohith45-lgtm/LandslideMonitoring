# Landslide Monitoring System
GitHub Pages prototype with multi-location sensors, color-coded mountain zones, 1 km checkposts, critical closure logic and emergency communication UI.

This is a prototype. Real life-safety thresholds, access closures, rescue procedures and communication infrastructure must be validated and operated by qualified authorities.
